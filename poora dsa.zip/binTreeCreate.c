#include <stdio.h>
#include <stdlib.h>
 
#define ABNODE 0

/* Binary Tree -- at max 2 Children */
struct treeNode {
    int data;
    struct treeNode *lchild;
    struct treeNode *rchild;
};

typedef struct treeNode tNode;
typedef tNode* tree;    // a variable of "tree" type is actually pointing to
                        // an address of a node of type "struct treeNode"

tree createTree() {
    tree t;
    int key; //node value of a tree node
    printf("Key?? [if node absent %d]: ", ABNODE);
    scanf("%d",&key);
    
    if(key == ABNODE)
        return NULL;
    
    //t = (tree) calloc(1, sizeof(tNode));
    t = (tree) malloc(sizeof(tNode));
    t->data = key;
    
    printf("\tlChild[%3d] : ", key);
    t->lchild = createTree();
 
    printf("\trChild[%3d] : ", key);
    t->rchild = createTree();
    
    return t;
}
// If a Binary Tree is constrained (guard condition) to accommodate at every node
// a value less or equal to data of node on its left and greater tha data of 
// node to its right
// .. BST (Ordered Binart Tree) .. Binary Search Tree

void preOrder(tree root){  //10--20--40--50--30--60--70
    if(root != NULL) {
        printf("%4d", root->data);        
        preOrder(root->lchild);       
        preOrder(root->rchild);     
    }
}

void postOrder(tree root){ //40--50--20--60--70--30--10
    if(root != NULL) {            
        postOrder(root->lchild);       
        postOrder(root->rchild);
        printf("%4d", root->data);     
    }
}

void inOrder(tree root){  //40--20--50--10--60--30--70
    if(root != NULL) {
        inOrder(root->lchild);   
        printf("%4d", root->data);       
        inOrder(root->rchild);     
    }
}



int main() {    
    tree root;
        root = createTree();
    printf("\nThe PREORDER Traversal...\n\t");
        preOrder(root);
    printf("\n");
    printf("\nThe POSTORDER Traversal...\n\t");
        postOrder(root);
    printf("\n");
    printf("\nThe INORDER Traversal...\n\t");
        inOrder(root);
    printf("\n");
    return 0;
}
