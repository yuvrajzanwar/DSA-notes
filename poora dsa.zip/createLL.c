//Program Documentation
// Aim:
// Date:
// Author:
//=============================================
// Header File Inclusion
#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>   .. getch()
//#include <math.h>    .. sqrt(), pow()

#define MAX 5

//Structure Definitions

    struct node {
        int data;
        struct node *link;
    };

    typedef struct node nodell;
    typedef nodell * list;

//Function Prototypes/Signatures/Declaration
    list createNode(void);
    list insertBeg(list, int);
    void displayLL(list);
    list deleteBeg(list, int *);

// Main Module
int main(){
    list first = NULL;   //empty linked list
    int key;
    displayLL(first);
    first = deleteBeg(first, &key); // address of "key"
    //function call
    first = insertBeg(first, 10);
    first = deleteBeg(first, &key);
    displayLL(first);

    first = insertBeg(first, 20);
    displayLL(first);
    first = insertBeg(first, 30);
    displayLL(first);
    first = insertBeg(first, 40);
    displayLL(first);
    first = deleteBeg(first, &key);
    displayLL(first);
    return 0;
}


// Function Definitions

list createNode(void){
    list neww;
    neww = (list) malloc(sizeof(struct node)); // returns a void pointer .. typecast
    return neww;
}

list insertBeg(list first, int key){
    list neww;
    neww = createNode();

    if(neww == NULL){
        printf("Availibility Stack Underflow\n");
        printf("Insertion Failed\n");
        return first;
    }
    //populate the node
    neww->data = key;
    neww->link = NULL;

    if(first == NULL)
        return neww;
    //LL is having atleast one node
    neww->link = first;
    return neww;
}

void displayLL(list first){

    if(first == NULL){
        printf("Empty List...\n");
        return;
    }
    printf("\nList Contents are...\n");
    while(first != NULL){
        printf("-->%d[%lu] ", first->data, (unsigned long) first);
        first = first->link;
    }
    printf("\n");
    return;
}

list deleteBeg(list first, int *key){
 // variable "key" is passed by reference
    list temp;

    if(first == NULL){
        printf("Delete Failed.. Empty List\n");
        *key = -999;
        return first;
    }
    temp = first; // save list address
    //now delete..
    first = first->link;
    *key = temp->data;
    free(temp); //restore the storage
    return first;
 }















